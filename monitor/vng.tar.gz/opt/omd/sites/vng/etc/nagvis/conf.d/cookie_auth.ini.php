[global]
logonmodule="LogonMultisite"
logon_multisite_htpasswd="/omd/sites/vng/etc/htpasswd"
logon_multisite_secret="/omd/sites/vng/etc/auth.secret"
logon_multisite_serials="/omd/sites/vng/etc/auth.serials"
