; <?php return 1; ?>
; -----------------------------------------------------------------
; Don't touch this file. It is under control of OMD. Modifying this
; file might break the update mechanism of OMD.
;
; If you want to customize your NagVis configuration please use the
; etc/nagvis/nagvis.ini.php file.
; -----------------------------------------------------------------

[global]
sesscookiepath="/vng/nagvis"
authorisation_group_perms_file="/omd/sites/vng/etc/nagvis/perms.db"

[paths]
base="/omd/sites/vng/share/nagvis/"
local_base="/omd/sites/vng/local/share/nagvis/"
cfg="/omd/sites/vng/etc/nagvis/"
mapcfg="/omd/sites/vng/etc/nagvis/maps/"
geomap="/omd/sites/vng/etc/nagvis/geomap/"
var="/omd/sites/vng/tmp/nagvis/"
sharedvar="/omd/sites/vng/tmp/nagvis/share/"
profiles="/omd/sites/vng/var/nagvis/profiles/"
htmlbase="/vng/nagvis"
local_htmlbase="/vng/nagvis/local"
htmlcgi="/vng/nagios/cgi-bin"

[defaults]
backend="vng"

[backend_vng]
backendtype="mklivestatus"
socket="unix:/omd/sites/vng/tmp/run/live"

[backend_vng_bi]
backendtype="mkbi"
base_url="http://localhost/vng/check_mk/"
auth_user="automation"
auth_secret_file="/omd/sites/vng/var/check_mk/web/automation/automation.secret"
timeout=10
