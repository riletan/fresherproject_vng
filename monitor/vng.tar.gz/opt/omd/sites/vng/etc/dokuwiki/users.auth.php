# <?php exit()?>
omdadmin:M29dfyFjgy5iA:OMD Admin:admin@example.org:admin,user
