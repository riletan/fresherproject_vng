<?php
$conf['savedir'] = '/opt/omd/sites/vng/var/dokuwiki/data/';
$conf['updatecheck'] = 0;
?>
