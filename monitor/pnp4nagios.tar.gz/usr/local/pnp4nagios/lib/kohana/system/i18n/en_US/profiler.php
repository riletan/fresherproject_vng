<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'benchmarks'   => 'Benchmarks',
	'post_data'    => 'Post Data',
	'no_post'      => 'No post data',
	'session_data' => 'Session Data',
	'no_session'   => 'No session data',
	'queries'      => 'Database Queries',
	'no_queries'   => 'No queries',
	'no_database'  => 'Database not loaded',
	'cookie_data'  => 'Cookie Data',
	'no_cookie'    => 'No cookie data',
);
