<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group' => 'Die Gruppe %s ist nicht in der Pagination-Konfiguration definiert worden.',
	'page'     => 'Seite',
	'pages'    => 'Seiten',
	'item'     => 'Element',
	'items'    => 'Elemente',
	'of'       => 'von',
	'first'    => 'Erste',
	'last'     => 'Letzte',
	'previous' => 'Vorherige',
	'next'     => 'Nächste',
);
