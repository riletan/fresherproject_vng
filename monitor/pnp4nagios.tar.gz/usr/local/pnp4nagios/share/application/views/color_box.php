<!-- Docs Menu Start -->
<div class="ui-widget">
<div class="p2 ui-widget-header ui-corner-top">
<?php echo Kohana::lang('common.icon-box-header') ?>
</div>
<div class="p4 ui-widget-content ui-corner-bottom" >
<?php 
echo "<a title=\"".Kohana::lang('common.title-home-link')."\" href=\"".url::base(TRUE)."graph\"><img class=\"icon\" src=\"".url::base()."media/images/home.png\"></a>\n";
echo "<a title=\"".Kohana::lang('common.title-docs-link')."\" href=\"".url::base(TRUE)."docs\"><img class=\"icon\" src=\"".url::base()."media/images/docs.png\"></a>\n";
echo "<a title=\"".Kohana::lang('common.title-color-link')."\" href=\"".url::base(TRUE)."color\"><img class=\"icon\" src=\"".url::base()."media/images/color.png\"></a>\n";
?>
</div>
</div>
<p>
<!-- Color Box End -->
